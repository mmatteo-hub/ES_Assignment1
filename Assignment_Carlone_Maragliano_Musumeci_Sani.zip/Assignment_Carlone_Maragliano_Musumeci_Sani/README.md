# ES Assignment 1

## Studenti Gruppo
* Matteo Carlone [ 4652067 ]
* Matteo Maragliano [ 4636216 ]
* Mattia Musumeci [ 4670261 ]
* Ettore Sani [ 5322242 ]
